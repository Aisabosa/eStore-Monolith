package com.ibm.rho.estore.model;

import org.springframework.util.MultiValueMap;

import org.springframework.util.LinkedMultiValueMap;

public class GetProductInvInventoryResponseWrapper {

	private InvItem response;

        public MultiValueMap<String, String> getHeaders(){
            final MultiValueMap<String, String> map=new LinkedMultiValueMap<String, String>();
            return map;
	}

	public void setHeaders(){
            
	}
 
	public InvItem getResponse(){
            return response;
	}
 
	public void setResponse(InvItem response){
            this.response=response;
	} 
}
